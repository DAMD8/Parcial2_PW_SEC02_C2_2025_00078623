// Datos generados usando JSON Generator con la estructura solicitada
const cuentas = [
  {
    _id: "48f93d9439f93e90c021",
    isActive: true,
    picture: "https://picsum.photos/id/7/200/300",
    balance: "$1250.75",
    client: "Ana García",
    gender: "female"
    
  },
  {
    _id: "48f93d9439f93e90c022",
    isActive: true,
    picture: "https://picsum.photos/id/8/200/300",
    balance: "$2845.30",
    client: "Carlos López",
    gender: "male"
  },
  {
    _id: "48f93d9439f93e90c023",
    isActive: false,
    picture: "https://picsum.photos/id/6/200/300",
    balance: "$875.20",
    client: "María Rodríguez",
    gender: "female"
  },
  {
    _id: "48f93d9439f93e90c024",
    isActive: true,
    picture: "https://picsum.photos/id/3/200/300",
    balance: "$3420.15",
    client: "Juan Martínez",
    gender: "male"
  },
  {
    _id: "48f93d9439f93e90c025",
    isActive: true,
    picture: "https://picsum.photos/id/4/200/300",
    balance: "$1567.80",
    client: "Laura Hernández",
    gender: "female"
  },
  {
    _id: "48f93d9439f93e90c026",
    isActive: true,
    picture: "https://picsum.photos/id/5/200/300",
    balance: "$2100.45",
    client: "Pedro Sánchez",
    gender: "male"
  },
  {
    _id: "48f93d9439f93e90c027",
    isActive: false,
    picture: "https://picsum.photos/id/1/200/300",
    balance: "$980.25",
    client: "Sofia Díaz",
    gender: "female"
  },
  {
    _id: "48f93d9439f93e90c028",
    isActive: true,
    picture: "https://picsum.photos/id/2/200/300",
    balance: "$4321.90",
    client: "Miguel Torres",
    gender: "male"
  }
];

module.exports = cuentas;