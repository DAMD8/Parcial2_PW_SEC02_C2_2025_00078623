//
const express = require('express');
const router = express.Router();
const cuentasController = require('../controllers/cuentas.controller');

router.get('/', (req, res) => {
    if (req.query.queryParam || req.query.isActive) {
        return cuentasController.getCuentaByQuery(req, res);
    }
    return cuentasController.getAllCuentas(req, res);
});
router.get('/:id', cuentasController.getCuentaById);
router.get('/extra/balance', cuentasController.getCuentasBalance);

module.exports = router;