
const cuentas = require('../data/cuentas');

exports.getAllCuentas = (req, res) => {
    res.json({
        count: cuentas.length,
        data: cuentas
    });
};

exports.getCuentaById = (req, res) => {
    const id = req.params.id;
    const cuenta = cuenta.find(c => c._id === id);
    if (cuenta) {
        res.json({ finded: true, account: cuenta });
    } else {
        res.json({ finded: false });
    } s
};

exports.getCuentaByQuery = (req, res) => {
    const query = req.query.queryParam;
    const isActiveFilter = req.query.isActive;
    let resultados = cuentas;

    if (isActiveFilter !== undefined) {
        const isActiveBool = isActiveFilter === 'true';
        resultados = resultados.filter(c => c.isActive === isActiveBool);
    }
    if (query) {
        resultados = resultados.filter(c =>
            c._id === query ||
            c.client.toLowerCase().includes(query.toLowerCase()) ||
            c.gender.toLowerCase() === query.toLowerCase()
        );
    }
    if (resultados.length === 0) {
        res.json({ finded: false });
    } else if (resultados.length === 1) {
        res.json({ finded: true, account: resultados[0] });
    } else {
        res.json({ finded: true, data: resultados });
    }
};
exports.getCuentasBalance = (req, res) => {
    const cuentasActivas = cuentas.filter(c => c.isActive);

    if (cuentasActivas.length === 0) {
        return res.json({
            status: false,
            accountBalance: 0
        });
    }

    const totalBalance = cuentasActivas.reduce((sum, cuenta) => {
        const balanceNum = parseFloat(cuenta.balance.replace('$', '').replace(',', ''));
        return sum + balanceNum;
    }, 0);

    res.json({
        status: true,
        accountBalance: parseFloat(totalBalance.toFixed(2))
    });
};